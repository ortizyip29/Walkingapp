package com.example.junhosung.aquagroupwalkingapp;

/**
 * Created by karti on 2018-03-10.
 */

public interface SimpleCallback<T> {
    void callback(T ans);
};